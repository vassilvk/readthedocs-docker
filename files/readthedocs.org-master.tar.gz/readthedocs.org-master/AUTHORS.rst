Original Authors
===============
* Charlie Leifer
* Eric Holscher
* Bobby Grace

Operations Team
===============

* Eric Holscher
* Chris McDonald

Awesome Contributors
====================
* Eric Pierce
* Chris Dickinson
* Jonas Obrist
* Issac Kelly
* Dan Colish
* Jacob Kaplan-Moss
* Paul McMillan
* Daniel Greenfeld
* Chris McDonald
* Daniel Graña
* Alex Gaynor
* Richard Boulton
* Mark Sandstrom
* Thomas Purchas
* Dustin J. Mitchell
* Michael Kurze
* Dag Odenhall
* Jacob Burch
* Julen Ruiz Aizpuru
* Manuel F. Viera
* Tom Offermann

For a list of all the contributions: https://github.com/rtfd/readthedocs.org/contributors

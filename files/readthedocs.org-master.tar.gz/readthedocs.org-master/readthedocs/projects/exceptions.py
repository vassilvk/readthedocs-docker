"""Project exceptions"""


class ProjectImportError (Exception):

    """Failure to import a project from a repository."""

    pass

default_app_config = 'readthedocs.gold.apps.GoldAppConfig'
